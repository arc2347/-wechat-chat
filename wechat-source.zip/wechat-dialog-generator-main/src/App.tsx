/**
 * Local two-person edition of gaopengbin/wechat-dialog-generator (MIT).
 * Reuses the upstream PhonePreview, MessageEditor, UserAvatarManager,
 * original chat styles and asset bundle; account/payment/export service removed.
 */
import { useCallback, useEffect, useRef, useState, type CSSProperties } from 'react';
import { ArrowDown, ArrowUp, Download, Eye, ImagePlus, MessageCircle, Pencil, Plus, RotateCcw, Send, Settings2, Trash2, UsersRound, X } from 'lucide-react';
import { PhonePreview } from '@/components/PhonePreview';
import { MessageEditor } from '@/components/MessageEditor';
import { UserAvatarManager } from '@/components/UserAvatarManager';
import { listProjects, saveProject, type ChatProject } from '@/lib/project-store';
import { parseChatRecord } from '@/lib/parser';
import type { ChatMessage, ChatUser, PhoneSettings } from '@/types';
import './components/Workspace.css';
import './mobile-chat.css';

const projectId = 'offline-two-person-chat';
const defaultUsers: ChatUser[] = [
  { id: 1, name: '我', avatar: null },
  { id: 2, name: '对方', avatar: null },
];
const defaultSettings: PhoneSettings = {
  platform: 'ios', time: '12:02', signal: 4, secondarySignal: 3,
  simMode: 'single', wifiEnabled: true, battery: 60, unreadCount: 0,
  contactName: '对方', selfBubbleColor: '#95ec69', otherBubbleColor: '#ffffff',
  backgroundColor: '#ededed', backgroundImage: null,
};
type MobileTab = 'chat' | 'edit' | 'people' | 'style';

function ChatViewport({ users, messages, settings, onUpdateMessage }: {
  users: ChatUser[];
  messages: ChatMessage[];
  settings: PhoneSettings;
  onUpdateMessage: (id: number, content: string) => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [metrics, setMetrics] = useState({ scale: 1 / 3, height: 2436 });
  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const update = () => {
      const rect = node.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const scale = rect.width / 1125;
      setMetrics(previous => {
        const height = rect.height / scale;
        return Math.abs(previous.scale - scale) < 0.0001 && Math.abs(previous.height - height) < 0.5 ? previous : { scale, height };
      });
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return <div className="local-chat-viewport" ref={containerRef} style={{ '--local-scale': metrics.scale, '--local-native-height': `${metrics.height}px` } as CSSProperties}>
    <PhonePreview users={users} messages={messages} settings={settings} selfId={1} simpleMode onUpdateMessage={onUpdateMessage} />
  </div>;
}

function App() {
  const [users, setUsers] = useState<ChatUser[]>(defaultUsers);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [settings, setSettings] = useState<PhoneSettings>(defaultSettings);
  const [tab, setTab] = useState<MobileTab>('chat');
  const [clean, setClean] = useState(false);
  const [sender, setSender] = useState(1);
  const [draft, setDraft] = useState('');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [editDraft, setEditDraft] = useState('');
  const [importDraft, setImportDraft] = useState('');
  const [loaded, setLoaded] = useState(false);
  const [saveStatus, setSaveStatus] = useState('本机保存');
  const [toast, setToast] = useState('');
  const toastTimer = useRef<number | null>(null);
  const imagePickerRef = useRef<HTMLInputElement>(null);
  const backgroundPickerRef = useRef<HTMLInputElement>(null);
  const jsonPickerRef = useRef<HTMLInputElement>(null);
  const lastTitleTap = useRef(0);

  const notice = useCallback((text: string) => {
    setToast(text);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(''), 2400);
  }, []);
  useEffect(() => {
    let cancelled = false;
    void listProjects().then(projects => {
      const previous = projects.find(project => project.id === projectId);
      if (!previous || cancelled) return;
      const loadedUsers = previous.users.slice(0, 2);
      if (loadedUsers.length === 2) setUsers([{ ...loadedUsers[0], id: 1 }, { ...loadedUsers[1], id: 2 }]);
      setMessages(previous.messages.filter(message => message.type === 'time' || [1, 2].includes(message.senderId)));
      setSettings({ ...defaultSettings, ...previous.settings });
    }).catch(() => {
      if (!cancelled) notice('浏览器不允许永久保存；当前会话仍可编辑');
    }).finally(() => { if (!cancelled) setLoaded(true); });
    return () => { cancelled = true; };
  }, [notice]);

  useEffect(() => {
    if (!loaded) return;
    setSaveStatus('保存中…');
    const timer = window.setTimeout(() => {
      const time = new Date().toISOString();
      const project: ChatProject = {
        id: projectId, version: 1, name: '双人聊天（离线版）', createdAt: time, updatedAt: time,
        users, messages, settings, importText: '', selfId: 1,
      };
      void saveProject(project).then(() => setSaveStatus('已自动保存')).catch(() => setSaveStatus('保存失败，请导出备份'));
    }, 550);
    return () => window.clearTimeout(timer);
  }, [users, messages, settings, loaded]);

  const addMessage = useCallback((message: Omit<ChatMessage, 'id'>) => {
    setMessages(current => [...current, { ...message, id: Math.max(0, ...current.map(item => item.id)) + 1 }]);
  }, []);
  const sendText = (event: React.FormEvent) => {
    event.preventDefault();
    if (!draft.trim()) return;
    addMessage({ type: 'text', senderId: sender, content: draft.trim(), params: {} });
    setDraft('');
  };
  const handleFileImage = (event: React.ChangeEvent<HTMLInputElement>, mode: 'message' | 'background') => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) { notice('请选择图片'); return; }
    if (file.size > 8 * 1024 * 1024) { notice('图片请小于 8 MB'); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const data = String(reader.result);
      if (mode === 'message') addMessage({ type: 'image', senderId: sender, content: data, params: {} });
      else setSettings(current => ({ ...current, backgroundImage: data }));
    };
    reader.readAsDataURL(file);
  };
  const updateMessage = (id: number, content: string) => setMessages(current => current.map(message => message.id === id ? { ...message, content } : message));
  const selectMessage = (message: ChatMessage) => { setSelectedId(message.id); setEditDraft(message.content); setTab('edit'); };
  const changeSelected = (patch: Partial<ChatMessage>) => setMessages(current => current.map(message => message.id === selectedId ? { ...message, ...patch } : message));
  const moveSelected = (offset: number) => {
    setMessages(current => {
      const from = current.findIndex(message => message.id === selectedId), to = from + offset;
      if (from < 0 || to < 0 || to >= current.length) return current;
      const result = [...current];
      [result[from], result[to]] = [result[to], result[from]];
      return result;
    });
  };
  const clearMessages = () => {
    if (!window.confirm('清空全部聊天消息？此操作无法撤销。')) return;
    setMessages([]); setSelectedId(null); notice('聊天记录已清空');
  };
  const importText = () => {
    const result = parseChatRecord(importDraft);
    if (!result.messages.length) { notice('未找到有效的聊天记录'); return; }
    if (result.users.length > 2) { notice('当前是双人版，请只填写两位角色的对话'); return; }
    const [self, other] = result.users;
    const mapped = result.messages.map((message, index) => ({ ...message, id: index + 1, senderId: message.type === 'time' ? 1 : message.senderId === self.id ? 1 : 2 }));
    setUsers([{ ...users[0], name: self?.name || '我' }, { ...users[1], name: other?.name || '对方' }]);
    setMessages(mapped);
    setSettings(current => ({ ...current, contactName: other?.name || '对方' }));
    setTab('chat'); notice(`已导入 ${mapped.length} 条消息`);
  };
  const makeBackup = () => {
    const backup = { type: 'wechat-dialog-generator-local-duo-v1', users, messages, settings };
    const data = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(data);
    const anchor = document.createElement('a');
    anchor.href = url; anchor.download = '双人聊天备份.json'; anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const restoreBackup = async (file: File | undefined) => {
    if (!file) return;
    try {
      const data: unknown = JSON.parse(await file.text());
      if (!data || typeof data !== 'object') throw new Error();
      const record = data as { users?: ChatUser[]; messages?: ChatMessage[]; settings?: PhoneSettings };
      if (!Array.isArray(record.users) || record.users.length !== 2 || !Array.isArray(record.messages) || !record.settings) throw new Error();
      setUsers(record.users);
      setMessages(record.messages);
      setSettings({ ...defaultSettings, ...record.settings });
      setTab('chat'); notice('已恢复聊天备份');
    } catch { notice('备份文件格式不正确'); }
  };
  const previewTap = () => {
    const now = Date.now();
    if (now - lastTitleTap.current < 520) { setClean(false); lastTitleTap.current = 0; }
    else lastTitleTap.current = now;
  };
  const other = users[1];
  const effectiveSettings = { ...settings, contactName: settings.contactName || other.name };
  const chosen = messages.find(message => message.id === selectedId);

  return <div className={`studio-app local-app${clean ? ' local-clean' : ''}`}>
    {!clean && <>
      <header className="local-topbar">
        <div className="local-brand"><MessageCircle size={22} /><div><strong>微信对话编辑器</strong><small>基于原版开源项目 · 本地版</small></div></div>
        <div className="local-top-actions"><span className="local-save-hint">{saveStatus}</span><button type="button" className="local-clean-button" onClick={() => { setTab('chat'); setClean(true); notice('双击聊天标题返回编辑'); }}><Eye size={16} />纯聊天</button></div>
      </header>
      <nav className="local-tabs" aria-label="功能切换">
        {([{ id: 'chat', label: '聊天', icon: MessageCircle }, { id: 'edit', label: '消息管理', icon: Pencil }, { id: 'people', label: '头像昵称', icon: UsersRound }, { id: 'style', label: '聊天外观', icon: Settings2 }] as const).map(item =>
          <button key={item.id} type="button" onClick={() => setTab(item.id)} className={tab === item.id ? 'active' : ''}><item.icon size={17} />{item.label}</button>)}
      </nav>
    </>}
    {(tab === 'chat' || clean) && <main className="local-chat-layout">
      <div className="local-chat-shell">
        <div className="local-chat-preview" onClickCapture={event => {
          if (!clean) return;
          const target = event.target as HTMLElement;
          if (target.closest('.wc-nav')) previewTap();
        }}>
          <ChatViewport users={users} messages={messages} settings={effectiveSettings} onUpdateMessage={updateMessage} />
          {clean && <button type="button" className="local-invisible-exit" aria-label="退出纯聊天预览" onClick={() => setClean(false)} />}
        </div>
        {!clean && <form className="local-composer" onSubmit={sendText}>
          <div className="local-sender-toggle" role="group" aria-label="消息发送方">
            <button type="button" className={sender === 1 ? 'selected' : ''} onClick={() => setSender(1)}>我发</button>
            <button type="button" className={sender === 2 ? 'selected' : ''} onClick={() => setSender(2)}>{other.name}发</button>
          </div>
          <div className="local-send-row">
            <button title="发送图片" aria-label="发送图片" type="button" className="local-pick-image" onClick={() => imagePickerRef.current?.click()}><ImagePlus size={21} /></button>
            <input ref={imagePickerRef} type="file" accept="image/*" hidden onChange={event => handleFileImage(event, 'message')} />
            <input value={draft} maxLength={4000} onChange={event => setDraft(event.target.value)} placeholder="输入文字，切换发送方模拟对话" aria-label="消息内容" />
            <button className="local-send" type="submit" disabled={!draft.trim()}><Send size={17}/><span>发送</span></button>
          </div>
        </form>}
      </div>
    </main>}
    {!clean && tab === 'edit' && <main className="local-page">
      <section className="local-panel"><div className="local-panel-heading"><h2>添加消息</h2><span>沿用原项目的消息编辑器</span></div><MessageEditor users={users} selfId={1} onAddMessage={addMessage} /></section>
      <section className="local-panel"><div className="local-panel-heading"><h2>全部消息 <small>({messages.length})</small></h2><button type="button" className="local-danger" onClick={clearMessages}><Trash2 size={15} />清空</button></div>
        {!messages.length ? <p className="local-note">还没有消息。回到「聊天」即可输入。</p> : <div className="local-message-list">{messages.map((message, index) => <button type="button" key={message.id} className={message.id === selectedId ? 'chosen' : ''} onClick={() => selectMessage(message)}><span>{index + 1}. {message.type === 'time' ? '时间' : message.senderId === 1 ? users[0].name : users[1].name}</span><b>{message.type === 'text' || message.type === 'time' ? message.content : message.type === 'image' ? '🖼️ 图片' : message.type === 'voice' ? `🎤 语音 ${message.params.duration ?? 3} 秒` : message.type === 'redpacket' ? '🧧 红包' : '💸 转账'}</b></button>)}</div>}
        {chosen && <div className="local-item-edit">
          <h3>编辑第 {messages.findIndex(message => message.id === selectedId) + 1} 条</h3>
          {chosen.type !== 'time' && <div className="local-role-edit"><button type="button" className={chosen.senderId === 1 ? 'selected' : ''} onClick={() => changeSelected({ senderId: 1 })}>我发</button><button type="button" className={chosen.senderId === 2 ? 'selected' : ''} onClick={() => changeSelected({ senderId: 2 })}>对方发</button></div>}
          {(chosen.type === 'text' || chosen.type === 'time') && <textarea value={editDraft} onChange={event => setEditDraft(event.target.value)} rows={3} />}
          {chosen.type === 'voice' && <label>语音时长（秒）<input type="number" min="1" max="60" value={chosen.params.duration ?? 3} onChange={event => changeSelected({ params: { ...chosen.params, duration: Number(event.target.value) } })} /></label>}
          {chosen.type === 'redpacket' && <label>红包备注<input value={chosen.params.remark ?? ''} onChange={event => changeSelected({ params: { ...chosen.params, remark: event.target.value } })} /></label>}
          {chosen.type === 'transfer' && <><label>转账金额<input value={chosen.params.amount ?? ''} onChange={event => changeSelected({ params: { ...chosen.params, amount: event.target.value } })} /></label><label>转账备注<input value={chosen.params.remark ?? ''} onChange={event => changeSelected({ params: { ...chosen.params, remark: event.target.value } })} /></label></>}
          <div className="local-edit-actions">
            {(chosen.type === 'text' || chosen.type === 'time') && <button type="button" className="primary" onClick={() => { updateMessage(chosen.id, editDraft); notice('修改已保存'); }}>保存文字</button>}
            <button type="button" onClick={() => moveSelected(-1)}><ArrowUp size={14}/>上移</button><button type="button" onClick={() => moveSelected(1)}><ArrowDown size={14}/>下移</button>
            <button type="button" className="danger" onClick={() => { setMessages(current => current.filter(message => message.id !== chosen.id)); setSelectedId(null); }}><Trash2 size={14}/>删除</button>
            <button type="button" onClick={() => setSelectedId(null)}><X size={14}/>关闭</button>
          </div>
        </div>}
      </section>
      <section className="local-panel"><h2>批量导入双人对话</h2><p className="local-note">每行一条，格式：我：你好 / 张三：在吗？支持原项目的图片、红包、语音等标记。</p><textarea rows={5} placeholder={'我：你好\n张三：你好呀'} value={importDraft} onChange={event => setImportDraft(event.target.value)} /><button type="button" className="local-wide-button" disabled={!importDraft.trim()} onClick={importText}><Plus size={16}/>解析并替换当前聊天</button></section>
      <section className="local-panel"><h2>本机备份</h2><p className="local-note">自动保存在当前浏览器。换设备前可导出 JSON 备份（不是聊天图片）。</p><div className="local-edit-actions"><button type="button" onClick={makeBackup}><Download size={15}/>备份数据</button><button type="button" onClick={() => jsonPickerRef.current?.click()}><RotateCcw size={15}/>恢复数据</button><input ref={jsonPickerRef} type="file" accept=".json,application/json" hidden onChange={event => { void restoreBackup(event.target.files?.[0]); event.target.value = ''; }} /></div></section>
    </main>}
    {!clean && tab === 'people' && <main className="local-page"><section className="local-panel"><h2>聊天双方</h2><p className="local-note">保持原项目的头像上传和角色管理功能。仅支持两个人。</p><div className="local-names">{users.map((user, index) => <label key={user.id}>{index === 0 ? '我的昵称' : '对方昵称'}<input value={user.name} maxLength={30} onChange={event => {
      const name = event.target.value;
      setUsers(current => current.map(item => item.id === user.id ? { ...item, name } : item));
      if (index === 1) setSettings(current => ({ ...current, contactName: name }));
    }}/></label>)}</div><UserAvatarManager users={users} selfId={1} onUpdateAvatar={(id, avatar) => setUsers(current => current.map(item => item.id === id ? { ...item, avatar } : item))} onRemoveAvatar={id => setUsers(current => current.map(item => item.id === id ? { ...item, avatar: null } : item))} onSetSelf={() => notice('双人版中右侧固定为“我”')} /></section></main>}
    {!clean && tab === 'style' && <main className="local-page"><section className="local-panel"><h2>聊天样式</h2><p className="local-note">直接使用原版微信聊天气泡和素材，不模拟信号、电量或手机外壳。</p><label>顶部聊天名称<input value={settings.contactName} onChange={event => setSettings(current => ({ ...current, contactName: event.target.value }))}/></label><div className="local-colors"><label>我的气泡颜色<input type="color" value={settings.selfBubbleColor} onChange={event => setSettings(current => ({ ...current, selfBubbleColor: event.target.value }))}/></label><label>对方气泡颜色<input type="color" value={settings.otherBubbleColor} onChange={event => setSettings(current => ({ ...current, otherBubbleColor: event.target.value }))}/></label><label>聊天背景颜色<input type="color" value={settings.backgroundColor} onChange={event => setSettings(current => ({ ...current, backgroundColor: event.target.value }))}/></label></div><div className="local-edit-actions"><button type="button" onClick={() => backgroundPickerRef.current?.click()}><ImagePlus size={16}/>上传背景图</button><button type="button" onClick={() => setSettings(current => ({ ...current, backgroundImage: null }))}><Trash2 size={16}/>移除背景图</button><input ref={backgroundPickerRef} type="file" accept="image/*" hidden onChange={event => handleFileImage(event, 'background')} /></div></section></main>}
    {toast && !clean && <div className="local-toast" role="status">{toast}</div>}
    <span className="sr-only" aria-live="polite">{clean ? '纯聊天模式，双击顶部聊天名称或点击右上方透明区域返回编辑' : ''}</span>
  </div>;
}

export default App;
